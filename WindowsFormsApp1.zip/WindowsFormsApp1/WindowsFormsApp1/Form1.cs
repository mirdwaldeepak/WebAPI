﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private int maxNumber = 0;
        private int currentNumber = 0;
        public Form1()
        {
            InitializeComponent();
            APIHelper.ApiIntializer();
            txtNext.Enabled = false;
        }

        private async Task LoadImage(int imagenumber = 0)
        {
            var comic = await ComicLoader.LoadComic(imagenumber);

            if(imagenumber == 0)
            {
                maxNumber = comic.Num;
            }
            currentNumber = comic.Num;
            picBox.ImageLocation =  comic.Img;
        }

        private async void Form1_Load(object sender, EventArgs e)
        {
            await LoadImage();
        }

        private async void txtPrevious_Click(object sender, EventArgs e)
        {
            if(currentNumber > 1)
            {
                currentNumber -= 1;
                txtNext.Enabled = true;
                await LoadImage(currentNumber);
                if(currentNumber == 1)
                {
                    txtPrevious.Enabled = false;
                }
            }
        }

        private async void txtNext_Click(object sender, EventArgs e)
        {
            if(currentNumber < maxNumber)
            {
                currentNumber += 1;
                txtPrevious.Enabled = true;
                await LoadImage(currentNumber);
                if(currentNumber == maxNumber)
                {
                    txtNext.Enabled = false;
                }
            }
        }
    }
}
