﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    public class ComicModel
    {
        public int Num { get; set; }
        public string Img { get; set; }
    }
}
